(function() {
    jQuery(document).ready(function() {
        jQuery("a.confluence-thumbnail-link").each(function() {
        jQuery(this).attr('rel', 'thumbnail-gallery');
         });
    });
})();