function foo() {
	return true;
}
