A very simple test plugin.

Adds "Google" link to all pages admin.

To make a JAR, use:

  cd src
  jar -cvf ../google-test-extension.jar .

To make a ZIP, use:

  cd src
  zip -r ../google-test-extension.zip . 

Any questions - ask me! mike@atlassian.com
