/**
 * The main module
 *
 * @context atl.general
 */
var $ = require('speakeasy/jquery').jQuery;
//var img = require('speakeasy/resources').getImageUrl(module, 'projectavatar.png');


	// make a faux body background
	function fauxBody (options) {

		var options = options || {},
			fill = options.fill || "none",
			fauxBodyZindex = options.zindex || -1, // Q: why is this forced to -1 instead of taking the passed in value of zero, if zero is passed in as a number?
			bodyWidth = $(document).width(),
			bodyHeight = $(document).height();

		// if fauxbg doesn't exist make it
		if ($("#fauxbg").length == 0) {
			$('<div id="fauxbg"></div>').css({ "position": "fixed", "top": 0, "left": 0, "margin": 0, "padding": 0, "overflow": "visible", "z-index": fauxBodyZindex }).appendTo("body");

			// using globals is bad but don't know how to fix it yet. Q: recommended way to do this?
			bg = Raphael("fauxbg", bodyWidth, bodyHeight); 
			bgsvg = bg.rect(0, 0).attr({ "fill": fill, "width" : bodyWidth, "height" : bodyHeight });

			// delay to avoid repeated resize events 
			var delay = (function(){ 
				var timer = 0; 
				return function(callback, ms){ 
					clearTimeout (timer); 
					timer = setTimeout(callback, ms); 
				}; 
			})(); 
			
			// add screen resize handler 
			$(window).resize(function () { 
				delay(function() { 
					fauxBody(); 
				}, 20); 
			});
		} else {
			// if fauxbg does exist, resize it
			bg.setSize(bodyWidth,bodyHeight);
			bgsvg.attr({"width": bodyWidth, "height" : bodyHeight});
			//console.log("resize " + bg + " new w/h " + bodyWidth + " " + bodyHeight);
		}
	   
	};

	// Q: neater way than this?
	function difference(a,b) {
		return Math.max(Math.abs(a),Math.abs(b)) - Math.min(Math.abs(a),Math.abs(b));
	}
	function isNegative(number) {
		return number < 0 ? true : false;
	}

	function makePath (options) {
		var options = options || {},
			minDogLeg = options.minDogLeg || 10,
			minLine = options.minline || 20,
			startX = Math.round(options[0]/10)*10,
			startY = Math.round(options[1]/10)*10,
			dogLeg = options[2],
			length = options[3];

		// ensure dogLeg meets minimum length
        if ( Math.abs(dogLeg) < minDogLeg ) {
            if (dogLeg < 0){
                //dogLeg -= minDogLeg; // increase by min, remains negative
                dogLeg = -minDogLeg; // set to min value (neg)
            } else {			
                //dogLeg += minDogLeg; // increase by min
                dogLeg = minDogLeg; // set to min value (pos)
            }
        }
	   
		var endX = startX + length,
			endY = startY + dogLeg,
			endY = Math.round(endY/10)*10,
			// firstPointX = (endX/2);
			firstPointX = ( startX + (length / 2) );

		if ( difference(firstPointX,startX) < minLine ) {
			firstPointX = +minLine;
		}
		if ( difference(secondPointX,endX) < minLine ) {
			// TODO: not quite sure if this numbers are going negative, this might not be required
			if ( isNegative(endX) ) {
				endX = -minLine;
			} else {
				endX = +minLine;
			}
		}

		var secondPointX = (firstPointX + Math.abs(dogLeg));
		//var secondPointX = (firstPointX + dogLeg);

		var pathString =  "M" + startX          + " " + startY  + "L" + firstPointX     + " " + startY;	// first line
			pathString += "M" + firstPointX     + " " + startY  + "L" + secondPointX    + " " + endY;	// dogleg from end of first line to start of second
			pathString += "M" + secondPointX    + " " + endY    + "L" + endX            + " " + endY;	// second line
	
		// console.log(pathString);
		return pathString;
	}

	function makeCircuit (options) {
		var options = options || {};

		var path = makePath(options.path),
			foreground = options.foreground || "#fff",
			background = options.background || "#000",
			strokeColour = options.strokeColour || "#A5FCF0",
			hoverColour = options.hoverColour || "#FFDF1B",
			strokeWidth = options.strokeWidth || 2,
			circleRadius = options.circleRadius || 5,
			lineAttrs = {
				"stroke": strokeColour,
				"stroke-width": strokeWidth,
				"stroke-linecap" : "round",
				"stroke-linejoin" : "round",
				"opacity": 0
			},
			circleAttrs = {
				"stroke": strokeColour,
				"stroke-width": strokeWidth,
				"fill": background,
				"opacity": 0
			},
			fadeInDuration = options.fadeInDuration || 1000;
	
		var line1 = bg.path(path).attr(lineAttrs),
			line1startpoint = line1.getPointAtLength(0),
			line1endpoint = line1.getPointAtLength(line1.getTotalLength()),
			circle1a = bg.circle(line1endpoint.x, line1endpoint.y, circleRadius).attr(circleAttrs),
			circle1b = bg.circle(line1startpoint.x, line1startpoint.y, circleRadius).attr(circleAttrs);

		var set = bg.set(line1, circle1a, circle1b).animate({ "opacity": 1 }, fadeInDuration );
		var circleSet = bg.set(circle1a, circle1b);

		if (!$.browser.msie) {
			line1.toBack();
	 	}

		// not useful once content is drawn over the top - beware of zindex/layering
		set.hover(function (event) {
			set.attr({stroke: hoverColour });
			//circleSet.attr({ fill: hoverColour });
		}, function (event) {
			set.attr({stroke: strokeColour });
			//circleSet.attr({ fill: background });
		});

		//console.log(set.getBBox().width);
	
	}

	function makeCircuits (options) {
		var options = options || {},
			startCircuits = options.startCircuits || 10,
			delayedCircuits = options.delayedCircuits || false,
			delayedCircuitsDelay = options.delayedCircuitsDelay || 1000;

		if (startCircuits) {
			for(var i = 0, ii = startCircuits; i < ii; i++) {
				//var startX = randomIsh2(2),
				//	startY = randomIsh2(2),
				//	dogLeg = randomIsh2(10),
				//	length = randomIsh2(1);

				var startX = randomThings({"type" : "xInViewport"}),
					startY = randomThings({"type" : "yInViewport"}),
					dogLeg = Math.floor(Math.random() * ( $(document).width() / 10) ),
					length = Math.floor(Math.random() * ( $(document).width() / 2) );

				makeCircuit({
					"path" : [startX,startY,dogLeg,length],
					"fadeInDuration" : 1000,
					"minDogLeg": 50,
					"minLine" : 50
				});
			}
		}
		if (delayedCircuits != false) {
			for(var i = 0; i < delayedCircuits; i++) {
				//console.log(i); 
				var delay = ( i + 1 ) * delayedCircuitsDelay;
				//console.log("delay " + delay);
				window.setTimeout(function() {
					//var startX = randomIsh2(2),
					//	startY = randomIsh2(2),
					//	dogLeg = randomIsh2(10),
					//	length = randomIsh2(1);

					var startX = randomThings({"type" : "xInViewport"}),
						startY = randomThings({"type" : "yInViewport"}),
						dogLeg = Math.floor(Math.random() * ( $(document).width() / 10) ),
						length = Math.floor(Math.random() * ( $(document).width() / 2) );

					makeCircuit({
						"path" : [startX,startY,dogLeg,length],
						"minDogLeg" : 50, 
						"minLine" : 50, 
						"fadeInDuration" : "3000"
					});
				}, delay);
			}
		}

	}

	function randomIsh2 (mod) {
		var max = ( $(document).width() / mod);
		return Math.floor(Math.random() * max)
		//return Math.floor( ( Math.random() / mod) * max)
	}

	function randomThings (options) {
		
		var option = options || {},
			type = options.type || "default",
			min = options.min,
			max = options.max;

		if ( type == "default") {
			return Math.random();
		}
		if ( type == "percent") {
			return Math.round(Math.random() * 100) + "%";
		}
		if ( type == "rgb") {
			return 'rgb(' + (Math.floor((256-199)*Math.random())) + ',' + (Math.floor((256-199)*Math.random())) + ',' + (Math.floor((256-199)*Math.random())) + ')';
		}
		if ( type == "hex") {
			return '#'+Math.floor(Math.random()*16777215).toString(16); // thanks @rioter
		}
		if ( type == "xInViewport") {
			return Math.floor(Math.random() * $(document).width());
		}
		if ( type == "yInViewport") {
			return Math.floor(Math.random() * $(document).height());
		}
		if ( type == "upToTenSeconds") {
			return Math.floor(Math.random() * 10000);
		}
	}

	$.fn.konami = function(callback, code) {
		if(code == undefined) code = "38,38,40,40,37,39,37,39,66,65";
		
		return this.each(function() {
			var kkeys = [];
			$(this).keydown(function(e){
				kkeys.push( e.keyCode );
				if ( kkeys.toString().indexOf( code ) >= 0 ){
					$(this).unbind('keydown', arguments.callee);
					callback(e);
				}
			}, true);
		});
	}
	
    function styleKiller() {
        //var keep = options.keep,
        //    styles = $("link[rel=stylesheet]"),
        //    ourStyle = $('link[href~="' + keep + '"]').clone()
        //    ;
        //styles.remove();
        //$("head").append(ourStyle);
        
        // jQuery("link[rel='stylesheet']").filter("link[href~='tronfluence']")
        // bah, wasting time
        
        $("*[style]").removeAttr("style"); // kill inline CSS
        $("*[align]").removeAttr("align"); // kill inline alignment
        $('link[href*="combined"]').remove(); // kill space CSS
        
        AJS.log("Styles killed");
        
    }

    function loadBling() {
        $("#full-height-container").fadeIn();
        AJS.log("loadBling 2");
    }


$(document).ready(function() {

    AJS.log("Tronfluence loaded");
    $('body').addClass("tronfluence");
    styleKiller();

    fauxBody({
        "fill" : "transparent",
        "zindex" : "0"
    });
    
    makeCircuits({
        startCircuits: 10,
        startCircuitsDelay: 1000,
        delayedCircuits: 10,
        delayedCircuitsDelay: 2000
    });

	//timeoutID = window.setTimeout(loadBling, 2000);
	//timeoutID = window.setTimeout(loadBling, 100);
    //if ( $("body").hasClass("dashboard") ) {
    //    timeoutID = window.setTimeout(loadBling, 200);
    //}
    timeoutID = window.setTimeout(loadBling, 500);

	$(window).konami(function(){
		window.location = "http://www.jangaron.net/jangaron0.6/jangaron.html";
	});

});

